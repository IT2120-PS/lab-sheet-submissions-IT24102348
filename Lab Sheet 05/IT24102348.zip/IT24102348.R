setwd('C:\\Users\\ASUS\\OneDrive - Sri Lanka Institute of Information Technology\\Academic\\3rd Semester\\IT2120 - Probability and Statistics\\Practicals\\Lab 05')

#1
Delivery_Times <- read.table('Exercise - Lab 05.txt',header = TRUE)
Delivery_Times <- Delivery_Times$Delivery_Time_.minutes

#2
histogram <-hist(Delivery_Times,main = "Delivery Times",breaks = seq(20,70,length = 10),right = FALSE)
 
#3
#The shape of the delivery time distribution is best described as both bimodal and skewed to the right.

cum_freq <- cumsum(histogram$counts)   
upper_bounds <- histogram$breaks[-1]  

#4
plot(
  upper_bounds, cum_freq,
  type = "o", col = "blue",
  main = "Cumulative Frequency Polygon (Ogive)",
  xlab = "Delivery Time (minutes)",
  ylab = "Cumulative Frequency"
)
